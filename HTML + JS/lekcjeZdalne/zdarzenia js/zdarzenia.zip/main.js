function papuga() {
    document.getElementById("wynik").innerHTML = "PAPUGA";
    document.getElementById("tresc").innerHTML = "Dignissimos et consequatur rem officiis ipsa consequatur laboriosam rerum.<br>Velit commodi et ipsam non.";
}

function zyrafa() {
    document.getElementById("wynik").innerHTML = "ŻYRAFA";
    document.getElementById("tresc").innerHTML = "Voluptatem est sunt ut ut eius necessitatibus quis.<br>Consequatur assumenda aspernatur quod.";
}

function krokodyl() {
    document.getElementById("wynik").innerHTML = "KROKODYL";
    document.getElementById("tresc").innerHTML = "Numquam delectus natus harum nobis neque aut.<br>Doloremque reiciendis id vero doloremque nisi quibusdam rem et autem.<br>Omnis ut aliquid perferendis labore occaecati error voluptas rerum aperiam.<br>Sed ut sed voluptates qui quae temporibus nobis consectetur consequatur.";
}

function zebra() {
    document.getElementById("wynik").innerHTML = "ZEBRA";
    document.getElementById("tresc").innerHTML = "Nulla molestias ullam velit et laboriosam placeat dignissimos blanditiis.<br>Culpa fugiat modi modi qui.";
}

function wilk() {
    document.getElementById("wynik").innerHTML = "WILK";
    document.getElementById("tresc").innerHTML = "Dolor fugiat enim minus.<br>Autem excepturi aut cupiditate corporis.<br>Occaecati pariatur quia. Voluptas eius velit est.";
}