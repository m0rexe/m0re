let imie = prompt("Podaj swoje imię");
let nazwisko = prompt("Podaj swoje nazwisko");

let i = "Imię: ";
let n = "Nazwisko: ";

document.write(i.fontcolor("red") + imie + "<br>");
document.write(n.fontcolor("blue") + nazwisko);